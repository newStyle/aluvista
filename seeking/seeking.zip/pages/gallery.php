<section class="mt10 mb12 down gallery">
	<section class="w22 mt8 mla mra pt1">
		<section class="w6 mt12 ml1 left">
			<p> our factory Gallary </p>
			<section></section><!-- small pic -->
			<div class="w3 paging"></div>
		</section>
		<section class="right pt1">
			<p class="right mt5"><span><a href="#play">play</a></span>/<span><a href="#puase">puase</a></span></p>
			<div class="w13 top mt12"></div>
			<div class="w11 mt7 down"></div>
		</section>
	</section> 
</section>
