<section class="mt2 mb11 b down pt1 color">
	<section class="mla mra mt11">
		<section class="w6 left">
			<div class="top">
				<article>
					<h4>Order Color </h4>
					<p>Diam aliquam enim et mus,
						amet, tincidunt velit.
					</p>
				</article>
			</div>
			<div class="mt5 down pt1">
				<section>
					<div><input class="active" type="button" value="diam"/></div>
					<div><input type="button" value="facilisis"/></div>
					<div><input type="button" value="aenean"/></div>
					<div><input type="button" value="integer"/></div>
					<div><input type="button" value="adipiscing"/></div>
					<div><input type="button" value="augue"/></div>
					<div><input type="button" value="aenean"/></div>
					<div><input type="button" value="Massa"/></div>
				</section>
			</div>
		</section>
		<section class="right">
			<section class="top">
				<article>
					<h4>Ultricies purus! Arcu a.</h4>
					<p>Massa aenean porttitor a turpis augue massa ut enim egestas platea et dis! Porta diam.
						Amet, urna porta vut auctor augue? Diam ac? Dictumst et dis velit amet sit.
						Risus, tortor scelerisque in porta diam et placerat enim a rhoncus, purus integer adipiscing.
						Nascetur adipiscing enim pulvinar sit! Rhoncus lorem porttitor elit. Et, enim quis odio natoque.
					</p>
				</article>
			</section>
			<section class="mt5 down pt1">
				<img class="colors" src="images/colors.png" width="500" height="343">
				<!--
				<section class="w12 mla mra">
					<section class="mt6">
						<div class="w3 left"></div>
						<div class="w3 left"></div>
						<div class="w3 left"></div>
						<div class="w3 mla last"></div>
					</section>
					<section class="mt6">
						<div class="w3 left"></div>
						<div class="w3 left"></div>
						<div class="w3 left"></div>
						<div class="w3 mla last"></div>
					</section>
					<section class="mt6">
						<div class="w3 left"></div>
						<div class="w3 left"></div>
						<div class="w3 left"></div>
						<div class="w3 mla last"></div>
					</section>
				</section>
				-->
			</section>
		</section>
	</section>
</section>