	<section class="mt12 down index">
		<div class="recent w6 left"></div>
		<section class="right">
			<section class="w16 mra ">
				<div class="left">
					<div class="top"></div>
					<div class="down">
						<p>Nunc elementum adipiscing.
							Urna, Ridiculus. </p>
					</div>
				</div>
				<div class="right">
					<div class="top"></div>
					<div class="down">
						<p>Nec quis integer tincidunt.
							Pulvinar scelerisque dis.</p>
					</div>
				</div>
				<div class="mla mra middle">
					<div class="top"></div>
					<div class="down">
						<p>Natoque, aenean tortor mattis tortor.
							Platea a cursus nec.</p>
					</div>
				</div>
			</section>
		</section>
	</section>
	<!-- End Content --> 
</section>
<!-- End Container -->